chrome.runtime.onMessage.addListener(funtion(response, sender, sendResponse), {
alert(response);
});